Problem:

Compass points in wrong direction compared to walking direction  [N/S vs E/W]
- 3 in logging area  [should be N/S]






Credit: BucketOfFriedChicken
License: Free. Just use.
