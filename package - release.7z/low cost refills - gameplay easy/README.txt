Change:

Medkits cost less to refill at supply shacks
- Fewer snakes needed



For players who need lots of healing help, especially in tougher areas




Credit: BucketOfFriedChicken
License: Free. Just use.
