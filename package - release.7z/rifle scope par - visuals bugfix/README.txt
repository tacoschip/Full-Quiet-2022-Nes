Problem:

Rifle scope is not circular when playing on 1:1 pixel-perfect, non-stretching display
- Reduces the visible area by 16 pixels





Note:

- Includes these patches first
  = "rifle scope hitbox"
  = "rifle scope mask"


- Do not use if playing on 4:3 display / 8:7 PAR stretching





Credit: BucketOfFriedChicken
License: Free. Just use.
