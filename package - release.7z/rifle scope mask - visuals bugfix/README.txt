Problem:

When looking through a rifle scope, sometimes enemy sprite pixels will appear inside
the black area outside the visible area

- More masking sprites are added to hide the stray dots





Credit: BucketOfFriedChicken
License: Free. Just use.
