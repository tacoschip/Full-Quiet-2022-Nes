Change:

Allow players to wakeup earlier in the morning
- Gives more time to explore before twilight deadline



More for players who want to sleep less in camps and just
keep running around





Credit: BucketOfFriedChicken
License: Free. Just use.
