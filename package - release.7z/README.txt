Version: 2023-04-17.1




Patches for "Full Quiet (USA, Europe) (Aftermarket) (Unl).nes"

- SHA1: 21AA545AAED35C6A4E13415174909D0DDD32EA73

- NES 2.0 header
  4e 45 53 1a 20 00 43 08 00 00 70 09 00 00 00 01






Basic play:
- Ammo reload icon  [visuals - bugfix]
- Compass bearing  [visuals - bugfix]
- Diary notes review  [misc - bugfix]
- Rifle scope hitbox  [gameplay - bugfix]


- Fast equip change  [gameplay - plus]


- Rifle scope par  [visuals - bugfix]

  # Meant for 1:1 pixel-perfect displays, not 8:7 / 4:3 stretch







Quick fun:
- Bigger backpack limit  [gameplay - easy]
- Early sleep wakeup  [gameplay - easy]
- Energy bar health  [gameplay - easy]
- Grid repair timer  [gameplay - easy]
- Low cost refills  [gameplay - easy]
- Pickup more items  [gameplay - easy]









Optional patches:
- Grid repair wrench  [gameplay - easy]









Tips:

1. Early reload your guns by double tapping d-up

2. Force crouch by double tapping d-down

3. Rotate the electric grid wires instead of blindly using them
