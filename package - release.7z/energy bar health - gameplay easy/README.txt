Change:

Energy bars give 7 health instead of 4

- Makes them feel less useless, considering how few of them can be
  found in some regions





Credit: BucketOfFriedChicken
License: Free. Just use.
