Problems:

1. Use menu to review old notes when in an area with a posted note.
   You can only see a limited number of messages

- It should cycle through all the previous messages you've collected



2. Use menu to review old notes when in the Plateau shack and view the
   "Get rest at camps!" message. When exiting shack, it wrongly shows Map B

- The game can randomly hard-crash later after triggering this map bug
- Only reading the fixed posted note in the shack should show the map



3. Use menu to review old notes in an area without a posted note.
   The notes will eventually get stuck on the "Thanks for playing!" message

- It should cycle through all the previous messages you've collected





Credit: BucketOfFriedChicken
License: Free. Just use.
