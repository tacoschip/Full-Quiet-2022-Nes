Change:

Picking up certain items gives more amount
- 5x snakes, rhyllekks, hissers
- More ropes, fuses, energy bars



Reduces time for item grinding and farming




Credit: BucketOfFriedChicken
License: Free. Just use.
