Problem:

Use up all the burst weapon's ammo. Now use up all the pistol's ammo without going to menu.
Reloading the pistol will show leftover burst bullet sprites

- Should be blank icons or pistol bullets





Credit: BucketOfFriedChicken
License: Free. Just use.
