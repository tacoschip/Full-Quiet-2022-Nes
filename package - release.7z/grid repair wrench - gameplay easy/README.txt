Change:

Picking up wrench during grid repair mini-game gives extra repair
- For players who find the mini-game too fast and frustrating




Credit: BucketOfFriedChicken
License: Free. Just use.
