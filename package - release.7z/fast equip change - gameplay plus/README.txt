Change:

Swap equipment in-game without going through menu
- Press D-Up + Select to use next weapon  (pistol, shotgun, burst, dynamite, sonic)
- Press D-Down + Select to use next tool  (lure, hook, pistol)





Credit: BucketOfFriedChicken
License: Free. Just use.
