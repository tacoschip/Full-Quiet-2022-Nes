Change:

Picking up clock icon during grid repair game gives more time bonus
- For players who find the mini-game too fast and frustrating





Credit: BucketOfFriedChicken
License: Free. Just use.
