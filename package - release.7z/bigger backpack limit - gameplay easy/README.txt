Change:

Gives player larger backpack and satchel storage space
- Useful more for shotgun and burst ammo, or ropes and fuses



Meant for players who want don't want to manage their ammo
shortages or low inventory, for more fun






Credit: BucketOfFriedChicken
License: Free. Just use.
