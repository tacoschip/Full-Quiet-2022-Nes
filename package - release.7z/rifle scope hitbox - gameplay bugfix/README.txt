Problem:

Firing rifle sometimes does not register a hit
- Targeting hitbox was off vertically by several pixels






Credit: BucketOfFriedChicken
License: Free. Just use.
